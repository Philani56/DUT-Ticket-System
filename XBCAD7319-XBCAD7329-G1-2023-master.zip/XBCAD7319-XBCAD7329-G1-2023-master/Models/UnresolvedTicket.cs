﻿//Mishra Mohammad - st10083182

using System;

//for unresolvedticket table
namespace Helpful_Hackers._XBCAD7319._POE.Models
{
    public class UnresolvedTicket
    {
        public int Id { get; set; }

        public DateTime DateAdded { get; set; }

    }
}
