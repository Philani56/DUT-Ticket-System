﻿using Helpful_Hackers._XBCAD7319._POE.Models;

namespace Helpful_Hackers._XBCAD7319._POE.Models
{
    public class Support
    {
        public string? Name { get; set; }
        public string? Email { get; set; }
        public string? Subject { get; set; }
        public string? Message { get; set; }
    }
}